-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 02, 2025 at 06:25 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dental_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
CREATE TABLE IF NOT EXISTS `appointment` (
  `appatientid` int NOT NULL AUTO_INCREMENT,
  `appdate` date NOT NULL,
  `patientid` int NOT NULL,
  `docid` int NOT NULL,
  `apptime` time(5) NOT NULL,
  `remark` varchar(100) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `appfor` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`appatientid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
CREATE TABLE IF NOT EXISTS `city` (
  `cityid` int NOT NULL AUTO_INCREMENT,
  `cityname` varchar(20) NOT NULL,
  `shortname` varchar(5) DEFAULT NULL,
  `pincode` int DEFAULT NULL,
  `stateid` int NOT NULL,
  PRIMARY KEY (`cityid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

DROP TABLE IF EXISTS `contactus`;
CREATE TABLE IF NOT EXISTS `contactus` (
  `contactid` int NOT NULL AUTO_INCREMENT,
  `contactdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fullname` varchar(30) NOT NULL,
  `contactno` int NOT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `details` varchar(200) DEFAULT NULL,
  `status` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`contactid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
CREATE TABLE IF NOT EXISTS `country` (
  `countryid` int NOT NULL AUTO_INCREMENT,
  `countryname` varchar(20) NOT NULL,
  `shortname` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`countryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

DROP TABLE IF EXISTS `email`;
CREATE TABLE IF NOT EXISTS `email` (
  `emailid` int NOT NULL AUTO_INCREMENT,
  `emaildate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `emailfrom` varchar(50) NOT NULL,
  `emailto` varchar(50) NOT NULL,
  `subject` varchar(30) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `regid` int NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `fbid` int NOT NULL AUTO_INCREMENT,
  `fbdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `feedback` varchar(100) NOT NULL,
  `fbfor` varchar(50) DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `regid` int NOT NULL,
  PRIMARY KEY (`fbid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

DROP TABLE IF EXISTS `inquiry`;
CREATE TABLE IF NOT EXISTS `inquiry` (
  `inqid` int NOT NULL AUTO_INCREMENT,
  `inqdate` datetime NOT NULL,
  `patientid` int NOT NULL,
  `inqdetail` varchar(200) DEFAULT NULL,
  `reply` varchar(50) DEFAULT NULL,
  `status` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`inqid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE IF NOT EXISTS `payment` (
  `payid` int NOT NULL AUTO_INCREMENT,
  `paydate` datetime NOT NULL,
  `paytype` varchar(15) NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `appattientid` int NOT NULL,
  `regid` int NOT NULL,
  PRIMARY KEY (`payid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

DROP TABLE IF EXISTS `prescription`;
CREATE TABLE IF NOT EXISTS `prescription` (
  `prsid` int NOT NULL AUTO_INCREMENT,
  `prsdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `medicine` varchar(100) NOT NULL,
  `patientid` int NOT NULL,
  `docid` int NOT NULL,
  `remark` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`prsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
CREATE TABLE IF NOT EXISTS `profile` (
  `regid` int NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  `cityid` int NOT NULL,
  `pincode` varchar(7) NOT NULL,
  `mobileno` int NOT NULL,
  `gender` int NOT NULL,
  `birthdate` date DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

DROP TABLE IF EXISTS `registration`;
CREATE TABLE IF NOT EXISTS `registration` (
  `regid` int NOT NULL AUTO_INCREMENT,
  `regdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `username` varchar(30) NOT NULL,
  `password` varchar(15) NOT NULL,
  `usertype` varchar(15) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `contactno` int DEFAULT NULL,
  PRIMARY KEY (`regid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reminder`
--

DROP TABLE IF EXISTS `reminder`;
CREATE TABLE IF NOT EXISTS `reminder` (
  `remid` int NOT NULL AUTO_INCREMENT,
  `remdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `patientid` int NOT NULL,
  `details` varchar(200) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `receptionname` varchar(30) NOT NULL,
  PRIMARY KEY (`remid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
CREATE TABLE IF NOT EXISTS `state` (
  `stateid` int NOT NULL AUTO_INCREMENT,
  `statename` varchar(30) NOT NULL,
  `shortname` varchar(5) DEFAULT NULL,
  `countryid` int NOT NULL,
  PRIMARY KEY (`stateid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

DROP TABLE IF EXISTS `treatment`;
CREATE TABLE IF NOT EXISTS `treatment` (
  `tid` int NOT NULL AUTO_INCREMENT,
  `tdate` datetime NOT NULL,
  `patientid` int NOT NULL,
  `docid` int NOT NULL,
  `tdetail` varchar(200) DEFAULT NULL,
  `remark` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `x-ray`
--

DROP TABLE IF EXISTS `x-ray`;
CREATE TABLE IF NOT EXISTS `x-ray` (
  `xrayid` int NOT NULL AUTO_INCREMENT,
  `xraydate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` int NOT NULL,
  `patientid` int NOT NULL,
  `docid` int NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`xrayid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
